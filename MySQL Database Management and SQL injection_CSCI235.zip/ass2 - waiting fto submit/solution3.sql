\set ECHO all

-- procedure
-- Create LONGTRIP function to cal the longest tripleg 
CREATE OR REPLACE FUNCTION LONGTRIP(DLNUM NUMERIC)
RETURNS NUMERIC AS $$
DECLARE
	longest_trip NUMERIC;
BEGIN
	-- cal with the longest tripleg
	SELECT COALESCE(MAX(legs), 0) INTO longest_trip
	FROM (
		SELECT t.tnum, COUNT(*) AS legs
		FROM TRIP t
		JOIN TRIPLEG tl ON t.tnum = tl.tnum
		WHERE t.lnum = DLNUM
		GROUP BY t.tnum
	) AS trip_lengths;

	-- return value (NULL or turn to 0)
	RETURN longest_trip;
END;
$$ LANGUAGE plpgsql;



-- query to select driver's longest trip
SELECT t.name, LONGTRIP(d.lnum) AS longestTrip
FROM DRIVER d
JOIN TRKEMPLOYEE t ON d.enum = t.enum;



\set ECHO none