\set ECHO all

-- totaltripmade column is set to update when there's a new TRIP
CREATE OR REPLACE FUNCTION update_total_trip_made()
RETURNS TRIGGER AS $$
BEGIN
    UPDATE DRIVER
    SET totalTripMade = (
        SELECT COUNT(*)
        FROM TRIP
        WHERE lnum = NEW.lnum
    )
    WHERE lnum = NEW.lnum;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;


-- the trigger
CREATE TRIGGER trip_insert_trigger
AFTER INSERT ON TRIP
FOR EACH ROW
EXECUTE FUNCTION update_total_trip_made();


-- insert employee to TRKEMPLOYEE table first
INSERT INTO TRKEMPLOYEE(enum, name, dob, address, hiredate)
VALUES (18, 'Theseus Bull', '1999-03-13', '2 Greek Mount Olympus, OLY 2050', '2025-07-03');

-- insert employee as a DRIVER (and not as mechanic)
INSERT INTO DRIVER(enum, lnum, status, totaltripmade)
VALUES (18, 40001, 'AVAILABLE', NULL);


-- insert said employee onto several trips in TRIP table
INSERT INTO TRIP(tnum, lnum, regnum, trip_date)
VALUES (109, 40001, 'KKK007', '2025-08-1');

INSERT INTO TRIP(tnum, lnum, regnum, trip_date)
VALUES (110, 40001, 'SST005', '2025-08-10');

INSERT INTO TRIP(tnum, lnum, regnum, trip_date)
VALUES (111, 40001, 'GFT008', '2025-08-20');


-- execute the trigger
SELECT * FROM DRIVER
WHERE lnum = 40001;


\set ECHO none