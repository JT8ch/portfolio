\set ECHO all


-- 1.
 /* NOTE to self- no need to insert new emp to table driver, just trkemployee */
 INSERT INTO TRKEMPLOYEE(enum, name, dob, address, hiredate)
 VALUES (16, 'Napoleon Bonaparte', '1990-09-15', '56 Waterloo Ave. Silent Hil, NSW 2502', '2025-03-16');
 CALL add_employee(16, 10009, 'AVAILABLE', 'driver');

 /*-- for reset
 DELETE FROM TRKEMPLOYEE
 WHERE enum=16;
 DELETE FROM DRIVER
 WHERE enum=16;
 /*

-- 2.
 /* instruction- execute insert, then execute either to mechanic or driver, and then execute the polar opposite of initial */
 INSERT INTO TRKEMPLOYEE(enum, name, dob, address, hiredate)
 VALUES (17, 'Alexander Hamilton', '1995-09-13', '6 Washington Ave. Street, NY505', '2025-03-17');
 CALL add_employee(17, 11005, 'AVAILABLE', 'mechanic', 'BEGINNER');
 CALL add_employee(17, 11005, 'AVAILABLE', 'driver');
 
/*
 DELETE FROM TRKEMPLOYEE
 WHERE enum=17;
 DELETE FROM DRIVER
 WHERE enum=17;
 DELETE FROM MECHANIC
 WHERE enum=17;
 */


-- 3.

CREATE OR REPLACE PROCEDURE add_employee(
    emp_no NUMERIC(12,0),
    license_no NUMERIC(8,0),
    status VARCHAR(10),
    role VARCHAR(10),
    experience VARCHAR(10) DEFAULT NULL  -- Move this to the end
)
LANGUAGE plpgsql AS $$
BEGIN
    -- Check if the employee is being added as a 'mechanic'
    IF role = 'mechanic' THEN
        -- Ensure the employee does not already exist as a driver
        IF EXISTS (
            SELECT 1
            FROM public.driver
            WHERE enum = emp_no OR lnum = license_no
        ) THEN
            RAISE EXCEPTION 'Employee % with license % already exists as a driver', emp_no, license_no;
        END IF;

        -- Insert the employee into the 'mechanic' table
        INSERT INTO public.mechanic (enum, lnum, status, experience)
        VALUES (emp_no, license_no, status, experience);

    -- Check if the employee is being added as a 'driver'
    ELSIF role = 'driver' THEN
        -- Ensure the employee does not already exist as a mechanic
        IF EXISTS (
            SELECT 1
            FROM public.mechanic
            WHERE enum = emp_no OR lnum = license_no
        ) THEN
            RAISE EXCEPTION 'Employee % with license % already exists as a mechanic', emp_no, license_no;
        END IF;

        -- Insert the employee into the 'driver' table
        INSERT INTO public.driver (enum, lnum, status, totaltripmade)
        VALUES (emp_no, license_no, status, 0);  -- Default total trips to 0

    ELSE
        -- Raise an error if the role is invalid
        RAISE EXCEPTION 'Invalid role: %. Allowed roles are "driver" or "mechanic"', role;
    END IF;
END;
$$;



\set ECHO none