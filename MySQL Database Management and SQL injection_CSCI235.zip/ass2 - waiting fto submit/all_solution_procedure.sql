-- T1 procedure

CREATE OR REPLACE PROCEDURE add_employee(
	emp_no NUMERIC(12,0),
	license_no NUMERIC(8,0),
	status VARCHAR(10),
	role VARCHAR(10),
	experience VARCHAR(10) DEFAULT NULL
)
LANGUAGE plpsql AS $$
BEGIN
	-- check emp for their role
	IF role = 'mechanic' THEN
		-- condition to check if emp already has another role
		IF EXISTS (
		SELECT 1
		FROM public.driver
		WHERE enum = emp_no OR lnum = license_no
		) THEN
		RAISE EXCEPTION 'Employee % with license % already exist as a driver', emp_no, license_no;
		END IF;

	-- if successful without issue it will be inserted
	INSERT INTO public.mechanic(enum, lnum, status, experience)
	VALUES (emp_no, license_no, status, experience);

	ELSE IF role = 'driver' THEN
		IF EXISTS (
		SELECT 1 
		FROM public.mechanic
		WHERE enum = emp_no OR lnum = license_no
		) THEN
		RAISE EXCEPTION 'Employee % with license % already exists as a mechanic', emp_no, license_no;
		END IF;

	-- if successful without issue it will be inserted
	INSERT INTO public.driver (enum, lnum, status, totaltripmade)
	VALUES (emp_no, license_no, status, NULL) 

	ELSE
	-- if unsuccessful and does not contain a role, show error message
	RAISE EXCEPTION 'Empty role: % allowed roles are "driver" or "mechanic" role', role;
	END IF;
END;
$$;



-- T2 procedure

-- totaltripmade column is set to update when there's a new TRIP
CREATE OR REPLACE FUNCTION update_total_trip_made()
RETURN TRIGGER AS $$
BEGIN
	UPDATE DRIVER
	SET totalTripMade = (
		SELECT COUNT(*)
		FROM TRIP
		WHERE lnum = NEW.lnum
	)
	WHERE lnum = NEW.lnum

	RETURN NEW;
END;
$$ LANGUAGE plpgsql;


-- the trigger
CREATE TRIGGER trip_insert_trigger
AFTER INSERT ON TRIP
FOR EACH ROW
EXECUTE FUNCTION update_total_trip_made();



-- T3 procedure

-- Create LONGTRIP function to cal the longest tripleg 
CREATE OR REPLACE FUNCTION LONGTRIP(DLNUM NUMERIC)
RETURNS NUMERIC AS $$
DECLARE
	longest_trip NUMERIC;
BEGIN
	-- cal with the longest tripleg
	SELECT COALESCE(MAX(legs), 0) INTO longest_trip
	FROM (
		SELECT t.tnum, COUNT(*) AS legs
		FROM TRIP t
		JOIN TRIPLEG tl ON t.tnum = tl.tnum
		WHERE t.lnum = DLNUM
		GROUP BY t.tnum
	) AS trip_lengths;

	-- return value (NULL or turn to 0)
	RETURN longest_trip;
END;
$$ LANGUAGE plpgsql;