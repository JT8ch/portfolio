1. open with visual studio code



2. Passwords.txt and device_pins.json should be in the same folder as device.py and connect.py



3. open device.py and connect.py



4. run code device.py (python -u "c:\Documents\SIM_CSCI262\ass1\device.py" (e.g))


	👌note - existing user - username: Alice, password: Alice123456

	- enter username and password
	- when PIN begins:
		- SPLIT TERMINAL (located at near bottom right corner, beside trash icon)
			- then:
				python -u "c:\Documents\SIM_CSCI262\ass1\connect.py" (e.g)



NOTE. as PIN begins to countdown, copy and paste the PIN to connect.py after logging in

IF. new user, has to register first at connect.py, then run device.py using username then repeat instruction.



5. run code connect.py 
	- python -u "c:\Documents\SIM_CSCI262\ass1\connect.py" (e.g)
	- either:
		- register (create new username and password)
		- login (exists: username: Alice, password: Alice123456)







