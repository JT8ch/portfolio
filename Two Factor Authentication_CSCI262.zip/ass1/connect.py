import time
import json
import re
import os

#function - load device PINs from JSON file
def load_device_pins():
    try:
        with open('device_pins.json', 'r') as file:
            return json.load(file)
    except FileNotFoundError:
        print("No device PINs found. Please run the device program first.")
        return {}

#function - check if passwords.txt exist, if not then create it
def create_password_file():
    if not os.path.exists('Passwords.txt'):
        with open('Passwords.txt', 'w') as file:
            file.write("")

#function - check if user/password exist  &&  login/reegister
def connect():
    create_password_file() 

    print("1. Login")
    print("2. Register")
    choice = input("Select an option: ")

    if choice == '1':
        username = input("Enter your username: ")
        password = input("Enter your password: ")
        if verify_credentials(username, password):
            print("Login successful!")
            device_pins = load_device_pins() #this will load the PIN from device program
            pin_authentication(username, device_pins)
        else:
            print("Invalid username or password. Please try again.")
            connect() 

    elif choice == '2':
        register() #go to def register to register user/password

#function - register a new user/password
def register():
    username = input("Enter a new username: ")
    password = input("Enter a new password: ")
    confirm_password = input("Confirm your password: ") #double check password

    if password == confirm_password and validate_password(password):
        with open('Passwords.txt', 'a') as file:
            file.write(f"{username} {password}\n")  #store username and password to file
        print("Registration successful! You can now log in.")
    else:
        print("Registration failed. Passwords do not match or do not meet criteria. Length more than 8 characters, one lower case, and one upper case.")
        register()  #if fail retry register again

#function - criteria for password
def validate_password(password):
    if (len(password) >= 8 and
        re.search(r'[a-z]', password) and
        re.search(r'[A-Z]', password)):
        return True
    return False

#function - verify the username and password input
def verify_credentials(username, password):
    try:
        with open('Passwords.txt', 'r') as file:
            for line in file:
                stored_username, stored_password = line.strip().split(' ', 1)  
                if stored_username == username and stored_password == password:
                    return True
    except FileNotFoundError: #user don't exist, must register
        print("No users found. Please register first.")
    return False

#function - matches device.py PIN to connect.py PIN input
def pin_authentication(username, device_pins):
    while True:
        pin = input("Enter your one-time PIN: ")

        if username in device_pins:
            stored_pin, expiration_time = device_pins[username]

            #condition - if it has been expired and moved to another PIN
            if pin.isdigit() and int(pin) == stored_pin:
                if time.time() < expiration_time:
                    print("Connection successful! Welcome.")
                    return
                else:
                    print("Error: This PIN has expired.")
            else:
                print("Error: Incorrect PIN.")
        else:
            print("Error: Username not found.")

        time.sleep(1)  #wait before enabled to allow input

#call the connect function
connect()
