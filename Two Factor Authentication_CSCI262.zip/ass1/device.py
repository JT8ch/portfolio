import random
import time
import threading
import json
import os

#store device username, username's one-time PIN, and expiration time
device_pins = {}

#function - check if password.txt exist, otherwise create it
def create_password_file():
    if not os.path.exists('Passwords.txt'):
        with open('Passwords.txt', 'w') as file:
            file.write("")

#function - login user/password  &&  password.txt exist
def device():
    create_password_file()
    
    username = input("Username: ")
    
    #condition - if user/pass don't exist in password.txt, register. otherwise retry if incorrect input
    if check_username(username):
        password = input("Password: ")

        if password:
            device_pin(username, password)
        else:
            print("Password is empty. Try again.")
            device()
    else:
        print("Username not found. Please register in the connect program.")
        print("Run 'connect.py' to register a new user.")
        return  #Will exit or loop back to the start

#function - check if username exists in password.txt to match credentials
def check_username(username):
    with open('Passwords.txt', 'r') as file:
        for line in file:
            stored_username, _ = line.strip().split(' ', 1)
            if stored_username == username:
                return True
    return False

#function - provide one-time PINs (6 digits) for 5 times  &&  expiration time
def device_pin(username, password):
    for _ in range(5):  #loop 5 times
        pin = random.randint(100000, 999999)  #6 digits PIN
        expiration_time = time.time() + 15  #expiration time
        device_pins[username] = (pin, expiration_time)  #store the generated pin/expiration time to device_pins, which will be call in connect.py

        print(f"One-time PIN for {username}: {pin} (Valid for 15 seconds)")

        #json file to store device_pins
        with open('device_pins.json', 'w') as file:
            json.dump(device_pins, file)

        #countdown of expiration time left
        countdown_thread = threading.Thread(target=countdown_timer, args=(username,))
        countdown_thread.start()

        countdown_thread.join() 

        print(f"PIN for {username} has expired. Generating a new one...\n")

def countdown_timer(username):
    for remaining in range(15, 0, -1):
        print(f"PIN valid for {remaining} seconds for {username}...", end='\r')
        time.sleep(1)  
    print() 

#call the device function to start the process
device()
